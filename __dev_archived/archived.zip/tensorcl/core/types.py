import numpy as np


np_single_types = [np.uint8, np.int8, np.uint16, np.int16, np.uint32, np.int32, np.uint64, np.int64, np.float16, np.float32, np.float64]
def is_number_type(value):
    return isinstance(value, (int, float) ) or value.__class__ in np_single_types
