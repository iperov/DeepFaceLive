import numpy as np

from ..core import OpenCL as CL
from .Buffer import Buffer
from .Device import Device


class Kernel:
    """
    TensorCL kernel.

    It does not allocate any resources, thus can be used as static variable within class.

    arguments

        kernel_text    OpenCL text of kernel. Must contain only one __kernel

        global_shape    default global_shape for .run()

        local_shape     default local_shape for .run()
    """
    def __init__(self, kernel_text, global_shape=None, local_shape=None):
        self._kernel_text = kernel_text
        self._global_shape = global_shape
        self._local_shape = local_shape

    def __str__(self):  return f'Kernel: \n{self._kernel_text}'
    def __repr__(self): return self.__str__()

    def run(self, device : Device, *args, global_shape=None, local_shape=None, global_shape_offsets=None, wait=False):
        """
        Run kernel on Device

        Arguments

            *args           arguments will be passed to OpenCL kernel
                            allowed types:

                            Buffer
                            np single value

            global_shape(None)  tuple of ints, up to 3 dims
                                amount of parallel kernel executions.
                                in OpenCL kernel,
                                id can be obtained via get_global_id(dim)

            local_shape(None)   tuple of ints, up to 3 dims
                                specifies local groups of every dim of global_shape.
                                in OpenCL kernel,
                                id can be obtained via get_local_id(dim)

            global_shape_offsets(None)  tuple of ints
                                        offsets for global_shape

            wait(False)     wait execution to complete
        """
        kernel = device._compile_kernel(self, self._kernel_text)

        if global_shape is None:
            global_shape = self._global_shape
        if global_shape is None:
            raise ValueError('global_shape must be defined.')

        work_dim = len(global_shape)
        global_shape_ar = (CL.c_size_t*work_dim)()
        for i,v in enumerate(global_shape):
            global_shape_ar[i] = v

        local_shape_ar = None
        if local_shape is None:
            local_shape = self._local_shape
        if local_shape is not None:
            if len(local_shape) != work_dim:
                raise ValueError('len of local_shape must match global_shape')

            local_shape_ar = (CL.c_size_t*work_dim)()
            for i,v in enumerate(local_shape):
                local_shape_ar[i] = v


        global_shape_offsets_ar = None
        if global_shape_offsets is not None:
            if len(global_shape_offsets) != work_dim:
                raise ValueError('len of global_shape_offsets must match global_shape')

            global_shape_offsets_ar = (CL.c_size_t*work_dim)()
            for i,v in enumerate(local_shape):
                global_shape_offsets_ar[i] = v

        for i, arg in enumerate(args):

            if isinstance(arg, Buffer):
                arg = arg.get_cl_mem()
            else:
                cl_type = Kernel._np_dtype_to_cl.get(arg.__class__, None)
                if cl_type is None:
                    raise ValueError(f'Cannot convert type {arg.__class__} to OpenCL type.')
                arg = cl_type(arg)

            clr = CL.clSetKernelArg(kernel, i, CL.sizeof(arg), CL.byref(arg))
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clSetKernelArg error: {clr}')

        ev = CL.cl_event() if wait else None

        clr = CL.clEnqueueNDRangeKernel(device._get_ctx_q(), kernel, work_dim, global_shape_offsets_ar, global_shape_ar, local_shape_ar, 0, None, ev)
        if clr != CL.CLERROR.SUCCESS:
            raise Exception(f'clEnqueueNDRangeKernel error: {clr}')

        if wait:
            CL.clWaitForEvents(1, (CL.cl_event*1)(ev) )
            CL.clReleaseEvent(ev)

    _np_dtype_to_cl = { np.uint8 : CL.cl_uchar,
                        np.int8 : CL.cl_char,
                        np.uint16: CL.cl_ushort,
                        np.int16: CL.cl_short,
                        np.uint32: CL.cl_uint,
                        np.int32: CL.cl_int,
                        np.uint64 : CL.cl_ulong,
                        np.int64: CL.cl_long,
                        np.float16: CL.cl_half,
                        np.float32: CL.cl_float,
                        np.float64: CL.cl_double }
