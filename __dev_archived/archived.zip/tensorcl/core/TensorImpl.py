from typing import Union
from .Tensor import Tensor
from .op.multi_wise_op import add, sub, mul, div, square
from .op.reshape import reshape
from .op.transpose import transpose

def Tensor__add__(self : Tensor, value) -> Tensor:
    if not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
        
    return add(self, value)
Tensor.__add__ = Tensor__add__
    
def Tensor__radd__(self : Tensor, value) -> Tensor:
    if not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
    return add(value, self)
Tensor.__radd__ = Tensor__radd__
        
def Tensor__sub__(self : Tensor, value) -> Tensor:
    if not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
    return sub(self, value)
Tensor.__sub__ = Tensor__sub__

def Tensor__rsub__(self : Tensor, value) -> Tensor:
    if not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
    return sub(value, self)
Tensor.__rsub__ = Tensor__rsub__
      
def Tensor__mul__(self : Tensor, value) -> Tensor:
    if self == value:
        return square(self)
    elif not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
    return mul(self, value)
Tensor.__mul__ = Tensor__mul__
          
def Tensor__rmul__(self : Tensor, value) -> Tensor:
    if self == value:
        return square(self)
    elif not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
    return mul(value, self)
Tensor.__rmul__ = Tensor__rmul__

def Tensor__truediv__(self : Tensor, value) -> Tensor:
    if not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
    return div(self, value)
Tensor.__truediv__ = Tensor__truediv__

def Tensor__rtruediv__(self : Tensor, value) -> Tensor:
    if not isinstance(value, Tensor):
        value = Tensor.from_value(value, device=self.get_device())
    return div(value, self)
Tensor.__rtruediv__ = Tensor__rtruediv__

Tensor.reshape = reshape
Tensor.transpose = transpose

__all__ = []