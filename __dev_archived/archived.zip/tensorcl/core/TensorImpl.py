from typing import Union
from .Tensor import Tensor
from .op.multi_wise_op import multi_wise_op
from .op.reshape import reshape

def Tensor__add__(self : Tensor, value) -> Tensor:
    if isinstance(value, (list,tuple)):
        value = Tensor.from_value(value, dtype=self.dtype, device=self.get_device())
        
    return multi_wise_op('O=A+B', self, value, op_name='add')
        
Tensor.__add__ = Tensor__add__
    
def Tensor__radd__(self : Tensor, value) -> Tensor:
    if isinstance(value, (list,tuple)):
        value = Tensor.from_value(value, dtype=self.dtype, device=self.get_device())
        
    return multi_wise_op('O=A+B', value, self, op_name='radd')
        
Tensor.__radd__ = Tensor__radd__
        
def Tensor__sub__(self : Tensor, value) -> Tensor:
    if isinstance(value, (list,tuple)):
        value = Tensor.from_value(value, dtype=self.dtype, device=self.get_device())
    return multi_wise_op('O=A-B', self, value, op_name='sub')
Tensor.__sub__ = Tensor__sub__

def Tensor__rsub__(self : Tensor, value) -> Tensor:
    if isinstance(value, (list,tuple)):
        value = Tensor.from_value(value, dtype=self.dtype, device=self.get_device())
    return multi_wise_op('O=A-B', value, self, op_name='rsub')
Tensor.__rsub__ = Tensor__rsub__
      
def Tensor__mul__(self : Tensor, value) -> Tensor:
    if isinstance(value, (list,tuple)):
        value = Tensor.from_value(value, dtype=self.dtype, device=self.get_device())
    return multi_wise_op('O=A*B', value, self, op_name='mul')
Tensor.__mul__ = Tensor__mul__
          
def Tensor__rmul__(self : Tensor, value) -> Tensor:
    if isinstance(value, (list,tuple)):
        value = Tensor.from_value(value, dtype=self.dtype, device=self.get_device())
    return multi_wise_op('O=A*B', self, value, op_name='rmul')
Tensor.__rmul__ = Tensor__rmul__

def Tensor_reshape(self : Tensor, new_shape) -> Tensor:
    return reshape(self, new_shape)
Tensor.reshape = Tensor_reshape
