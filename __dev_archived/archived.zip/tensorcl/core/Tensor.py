from typing import Iterable, Union,List

import numpy as np

from .TensorShape import TensorShape
from .DeviceInfo import DeviceInfo

from .Device import Device, get_device
from .Buffer import Buffer

_np_single_types = {np.uint8, np.int8, np.uint16, np.int16, np.uint32, np.int32, np.uint64, np.int64, np.float16, np.float32, np.float64 }

class Tensor:
    """
        shape   TensorShape
                Iterable

        dtype   numpy.dtype

        device(None)  int|Device|DeviceInfo
    """

    @staticmethod
    def from_value(value,
                   dtype:np.dtype=None,
                   device:Union[None,int,Device,DeviceInfo]=None) -> 'Tensor':
        """
        Produces new Tensor with the same shape and dtype as value
        and set the value to the Tensor immediately.

        arguments

        value      Tensor
                   int, float, np single value
                   np.ndarray

        dtype(None)     for non np values

        device(None)  int|Device|DeviceInfo
        """
        if isinstance(value, (list, tuple) ):
            if dtype is None:
                raise ValueError('dtype must be specified for list of undefined values.')
            value = np.array(value, dtype=dtype)
        elif isinstance(value, (int, float) ):
            if dtype is None:
                raise ValueError('dtype must be specified for python int/float value.')
            value = np.array([value], dtype=dtype)
        elif value.__class__ in _np_single_types:
            value = np.array([value], dtype=value.dtype)
        elif not isinstance(value, (Tensor, np.ndarray) ):
            raise ValueError(f'Unsupported value {value} ({value.__class__})')

        t = Tensor(shape=value.shape, dtype=value.dtype, device=device)
        t.set(value, wait=True)
        return t

    def __init__(self, shape : Union[TensorShape, Iterable],
                       dtype : np.dtype,
                       device : Union[None,int, Device, DeviceInfo] = None,
                       ):
        Tensor._object_count += 1
        self._seq_id = Tensor._seq_id = Tensor._seq_id + 1

        self.shape = shape = TensorShape(shape)

        if isinstance(dtype, np.dtype):
            dtype = dtype.type
        if dtype not in _np_single_types:
            raise ValueError(f'Unsupported dtype {dtype}')
        self.dtype = dtype = np.dtype(dtype)

        self._device = device = get_device(device)

        self._op_name = None    # optional name of op which produces this Tensor
        self._buffer = Buffer(device, size=shape.size*dtype.itemsize)

    def __del__(self):
        print('Tensor __del__')
        Tensor._object_count -= 1

    def __add__(self, value) -> 'Tensor': raise NotImplementedError()
    def __radd__(self, value) -> 'Tensor': raise NotImplementedError()
    def __sub__(self, value) -> 'Tensor': raise NotImplementedError()
    def __rsub__(self, value) -> 'Tensor': raise NotImplementedError()
    def reshape(self, new_shape) -> 'Tensor':
        """
        Reshape operator.

        arguments

            new_shape   tuple of ints
        """
        raise NotImplementedError()

    def _as_ref(self, shape) -> 'TensorRef':
        """
        Convert to Reference Tensor with new_shape.

            shape must have the same size as tensor's shape
        """
        return TensorRef(self, shape)

    def _is_reference(self) -> bool: return False
    def _get_reference_source(self) -> 'Tensor': return self
    def _get_seq_id(self) -> int: return self._seq_id
    def get_device(self) -> Device: return self._device
    def _get_buffer(self) -> Buffer: return self._buffer

    def _set_op_name(self, op_name):
        """
        set op name
        """
        self._op_name = op_name

    def get_name(self):
        """
        returns name of the Tensor
        """
        name = f'#{self._get_seq_id()}'
        if self._op_name is not None:
            name += f'({self._op_name})'
        return name

    def is_same_device_as(self, tensor_or_list : Union['Tensor', List['Tensor'] ] ) -> bool:
        """
        """
        if not isinstance(tensor_or_list, (list,tuple)):
            tensor_or_list = (tensor_or_list,)

        device = self.get_device()
        return all( device == tensor.get_device() for tensor in tensor_or_list )

    def set(self, value, wait=True):
        """
        Set tensor value

            Parameters

            value   Tensor    copy data from Tensor. Can be with different shape, but should match size of shape.

                    Scalar number   will be treated as (1,) array

                    np.ndarray      must match dtype

            wait(True)      if not wait and arg is np.ndarray,
                            then you should not delete or modify np.ndarray value during execution
        """
        if isinstance(value, Tensor):
            if self.shape.size != value.shape.size:
                raise ValueError('Unable to set data from other tensor: shape.size is not the same.')
            self._get_buffer().set(value._get_buffer())
        else:
            if isinstance(value, np.ndarray):
                if value.dtype != self.dtype:
                    raise ValueError('dtype of value must match tensor dtype')
            else:
                if isinstance(value, (int, float)):
                    value = np.array([value], dtype=self.dtype)
                elif isinstance(value, (list,tuple)):
                    value = np.array(value, dtype=self.dtype)
                else:
                    raise ValueError(f'Unknown type {value.__class__}')

            self._get_buffer().set(value, wait=wait)

    def np(self):
        """
        Returns numpy value of a Tensor
        """
        return self._get_buffer().np(self.shape, self.dtype)

    def __str__(self): return f"T {self.get_name()} {self.shape} {self.dtype}"

    def __repr__(self):
        s  = self.__str__() + '\n'
        s += str(self.np()) + '\n'
        s += self.__str__()
        return s

    _object_count = 0
    _seq_id = 0



class TensorRef(Tensor):
    """
    TensorRef used to interpret existing Tensor with different shape.
    use Tensor._as_ref() method
    """

    def __init__(self, t : Tensor, shape):
        shape = TensorShape(shape)
        if t.shape.size != shape.size:
            raise ValueError(f'Cannot interpet shape {t.shape} as ref shape {shape}')
        super().__init__(shape, dtype=t.dtype, device=t.get_device())
        self._t = t


    def _is_reference(self) -> bool:           return True
    def _get_reference_source(self) -> Tensor: return self._t

    # Forward methods to original tensor
    def _get_seq_id(self) -> int:              return self._t._get_seq_id()
    def get_device(self) -> Device: return self._t.get_device()
    def _get_buffer(self) -> Buffer: return self._t._get_buffer()

