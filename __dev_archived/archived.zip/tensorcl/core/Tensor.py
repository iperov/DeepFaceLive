from typing import Iterable, List, Union

import numpy as np

from .Buffer import Buffer
from .Device import Device, get_default_device, get_device
from .DeviceInfo import DeviceInfo
from .initializer import Initializer
from .TensorShape import TensorShape
from .types import is_number_type


class Tensor:
    """
        shape   TensorShape
                Iterable

        device(None)  int|Device|DeviceInfo
    """

    @staticmethod
    def from_value(value,
                   device:Union[None,int,Device,DeviceInfo]=None) -> 'Tensor':
        """
        Produces new Tensor with the same shape and dtype as value
        and set the value to the Tensor immediately.

        arguments

        value      Tensor
                   int, float, np single value
                   np.ndarray

        device(None)  None      (default)
                      int       (index)
                      Device    
                      DeviceInfo
        """
        if isinstance(value, (list, tuple) ):
            value = np.array(value, dtype=np.float32)
        elif is_number_type(value):
            value = np.array([value], dtype=np.float32)
        elif isinstance(value, np.ndarray ):
            ...
        elif isinstance(value, Tensor ):
            device = value.get_device()
        else:
            raise ValueError(f'Unsupported value type {value.__class__}')

        t = Tensor(shape=value.shape, device=device)
        t.set(value)
        return t

    def __init__(self, shape : Union[TensorShape, Iterable],
                       device : Union[None, int, Device, DeviceInfo] = None,
                       initializer : Initializer = None,
                       ):
        Tensor._object_count += 1
        self._seq_id = Tensor._seq_id = Tensor._seq_id + 1

        self.shape = shape = TensorShape(shape)
        self.dtype = dtype = np.float32()

        self._device = device = get_default_device() if device is None else get_device(device)
        self._initializer = initializer
        
        self._buffer = Buffer(device, 
                              size=shape.size*dtype.itemsize,
                              init_func=self._initializer_func if initializer is not None else None)
        
        self._op_name = None    # optional name of op which produces this Tensor

    def _initializer_func(self, buffer : Buffer):
        self._initializer.initialize_buffer(buffer, self.shape)
    
    def __del__(self):
        Tensor._object_count -= 1
    def __add__(self, value) -> 'Tensor': raise NotImplementedError()
    def __radd__(self, value) -> 'Tensor': raise NotImplementedError()
    def __sub__(self, value) -> 'Tensor': raise NotImplementedError()
    def __rsub__(self, value) -> 'Tensor': raise NotImplementedError()
    def __mul__(self, value) -> 'Tensor': raise NotImplementedError()
    def __rmul__(self, value) -> 'Tensor': raise NotImplementedError()
    def __truediv__(self, value) -> 'Tensor': raise NotImplementedError()
    def __rtruediv__(self, value) -> 'Tensor': raise NotImplementedError()
            
    def reshape(self, new_shape) -> 'Tensor':
        """
        Reshape operator.

        arguments

            new_shape   tuple of ints
        """
        raise NotImplementedError()
        
    def transpose(self, axes_order) -> 'Tensor':
        """
        Transpose operator.

        arguments

            axes_order   tuple of ints
        """
        raise NotImplementedError()
        
    def _as_ref(self, shape) -> 'TensorRef':
        """
        Convert to Reference Tensor with new_shape.

            shape must have the same size as tensor's shape
        """
        return TensorRef(self, shape)

    def _is_reference(self) -> bool: return False
    def _get_reference_source(self) -> 'Tensor': return self
    def _get_seq_id(self) -> int: return self._seq_id
    def _get_buffer(self) -> Buffer: return self._buffer

    def _set_op_name(self, op_name):
        """
        set op name
        """
        self._op_name = op_name
        
    def get_device(self) -> Device: return self._device
    
    def get_name(self):
        """
        returns name of the Tensor
        """
        name = f'#{self._get_seq_id()}'
        if self._op_name is not None:
            name += f'({self._op_name})'
        return name

    def is_same_device_as(self, tensor_or_list : Union['Tensor', List['Tensor'] ] ) -> bool:
        """
        check if all tensors in a list use the same device
        """
        if not isinstance(tensor_or_list, (list,tuple)):
            tensor_or_list = (tensor_or_list,)

        device = self.get_device()
        return all( device == tensor.get_device() for tensor in tensor_or_list )

    def set(self, value):
        """
        Set tensor value

            Parameters

            value   Tensor    copy data from Tensor. Can be with different shape, but should match size of shape.

                    Scalar number   will be treated as (1,) array

                    np.ndarray      will be converted to tensor's dtype
        """
        if isinstance(value, Tensor):
            if self.shape.size != value.shape.size:
                raise ValueError('Unable to set the data from other tensor: shape.size is not the same.')
            self._get_buffer().set(value._get_buffer())
        else:
            if isinstance(value, np.ndarray):
                value = value.astype(self.dtype)
            else:
                if is_number_type(value):
                    value = np.array([value], dtype=self.dtype)
                elif isinstance(value, (list,tuple)):
                    value = np.array(value, dtype=self.dtype)
                else:
                    raise ValueError(f'Unknown type {value.__class__}')

            self._get_buffer().set(value)

    def np(self):
        """
        Returns numpy value of a Tensor
        """
        return self._get_buffer().np(self.shape, self.dtype)

    def __str__(self): return f"T {self.get_name()} {self.shape} {self.dtype.__class__.__name__}"

    def __repr__(self):
        s  = self.__str__() + '\n'
        s += str(self.np()) + '\n'
        s += self.__str__()
        return s

    _object_count = 0
    _seq_id = 0



class TensorRef(Tensor):
    """
    TensorRef used to interpret existing Tensor with different shape.
    use Tensor._as_ref() method
    """

    def __init__(self, t : Tensor, shape):
        shape = TensorShape(shape)
        if t.shape.size != shape.size:
            raise ValueError(f'Cannot interpet shape {t.shape} as ref shape {shape}')
        super().__init__(shape, device=t.get_device())
        self._t = t


    def _is_reference(self) -> bool:           return True
    def _get_reference_source(self) -> Tensor: return self._t

    # Forward methods to original tensor
    def _get_seq_id(self) -> int:              return self._t._get_seq_id()
    def _get_buffer(self) -> Buffer: return self._t._get_buffer()
    def get_device(self) -> Device: return self._t.get_device()

