import numpy as np
from .Initializer import Initializer
from ..Kernel import Kernel
from ..Buffer import Buffer
from ..KernelHelper import KernelHelper as KH
from ..TensorShape import TensorShape
from ..Cacheton import Cacheton

class _RandomUniform(Initializer):
    def __init__(self, low, high):
        self._low = low
        self._high = high
        self._kernel = Kernel(kernel_text=f"""
{KH.include_hash()}

__kernel void impl(__global float* O, uint seed)
{{
    size_t gid = get_global_id(0);
    O[gid] = hash_float_uint(gid+seed)*({high}-({low}))+({low});
}}
""")
        
    def initialize_buffer(self, buffer : Buffer, shape : TensorShape):
        seed = np.random.randint(2147483648)
        self._kernel.run( buffer.get_device(), buffer, np.uint32(seed), global_shape=(shape.size,) )
        
    def __str__(self):  return f'RandomUniform low={self._low}, high={self._high}'

def RandomUniform(low=0.0, high=1.0):
    """
    returns initializer of random uniform.
    
    arguments
     
     low(0.0)   low value
     
     high(1.0)  high value
    """
    return Cacheton.get( _RandomUniform, low, high )
