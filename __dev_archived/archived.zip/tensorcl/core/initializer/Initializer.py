from ..Buffer import Buffer
from ..TensorShape import TensorShape

class Initializer:
    """
    Base class for inititalizers  
    """
    def initialize_buffer(self, buffer : Buffer, shape : TensorShape):
        """
        Implement initialization of Buffer
        
        You can compute the data using python and then call buffer.set(numpy_value)
        or call kernel.run( buffer.get_device(), buffer, ...) to initialize the data using OpenCL        
        """
        raise NotImplementedError()
        
    def __str__(self): return 'Initializer'        
    def __repr__(self): return self.__str__()
