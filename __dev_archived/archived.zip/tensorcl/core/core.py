from .Cacheton import Cacheton
from .Tensor import Tensor
from .Device import cleanup_devices

def cleanup():
    """
    """
    Cacheton.cleanup()
    
    if Tensor._object_count != 0:
        raise Exception(f'Unable to cleanup while {Tensor._object_count} Tensor objects exist.')
        
    cleanup_devices()
    

