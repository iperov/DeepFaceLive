import traceback
from typing import List, Union, Tuple
import numpy as np
from ..Tensor import Tensor
from ..Kernel import Kernel
from ..Device import Device
from ..TensorShape import TensorShape
from ..info.InfoBroadcast import InfoBroadcast
from ..KernelHelper import KernelHelper as KH
from ..types import is_number_type
from ..Cacheton import Cacheton

def multi_wise_op(op_text : str, 
                  *args, 
                  output_t:Tensor=None, 
                  op_name:str=None) -> Tensor:
    """
    operator for MultiWiseOpKernel ops with N inputs

    arguments
        op_text     example: O=(2*I0*I1)+I2

        *args       List[ Tensor | number ]

        output_t            compute result to this Tensor.
                            Tensor may be with different shape, but should match total size.
                            gradfn will not be set.

        op_name
    """

    if len(args) == 0:
        raise ValueError('args must be specified')

    tensor_args = [arg for arg in args if isinstance(arg, Tensor) ]
    if len(tensor_args) == 0:
        raise ValueError('At least one arg must be a Tensor')

    args_shapes = []
    krn_args = []
    for arg in args:
        if isinstance(arg, Tensor):
            args_shapes.append(arg.shape)
            krn_args.append(arg._get_buffer())
        elif is_number_type(arg):
            args_shapes.append(None)
            krn_args.append(np.float32(arg))
        else:
            raise ValueError(f'Unsupported type of arg: {arg.__class__} Use Tensor or number type.')

    device = tensor_args[0].get_device()
    op = Cacheton.get(_MultiWiseOp, tuple(args_shapes), op_text)

    if output_t is None:
        output_t = Tensor ( op.info.output_shape, device=device )
        if op_name is not None:
            output_t._set_op_name (op_name)
    elif output_t.shape.size != op.info.output_shape.size:
        raise ValueError(f'output_t must have size { op.info.output_shape.size }')

    op.forward_krn.run(device, output_t._get_buffer(), *krn_args)

    return output_t

class _MultiWiseOp:
    def __init__(self, args_shapes : List[Tuple[ Union[TensorShape,None], np.dtype]],
                       op_text : str):

        self.info = info = InfoBroadcast( [ shape if shape is not None else TensorShape( (1,) ) for shape in args_shapes  ])

        defs, arg_defs, impls = [], [], []
        for i, shape in enumerate(args_shapes):
            axis_letter = f'I{i}'
            if shape is not None:
                defs.append( KH.define_axes_accessor(f"{axis_letter}", info.br_shapes[i]) )
                arg_defs.append( f", __global const float* {axis_letter}_t" )
                impls.append( f"float {axis_letter} = {axis_letter}_t[{axis_letter}_idx_mod({KH.axes_seq_enum('o', info.output_shape.rank)})];")
            else:
                arg_defs.append( f", float {axis_letter}" )

        defs, arg_defs, impls = '\n'.join(defs), '\n'.join(arg_defs), '\n'.join(impls)

        self.forward_krn = Kernel(global_shape=(info.output_shape.size,), kernel_text=f"""
{defs}
{KH.define_axes_accessor('O', info.output_shape)}
__kernel void impl(__global float* O_t{arg_defs})
{{
size_t gid = get_global_id(0);
{KH.axes_idxs_from_var('o', info.output_shape.rank, 'gid')}
{impls}

float O = O_t[gid];
{op_text};
O_t[gid] = O;
}}
""")

def add(a_t : Tensor, b_t : Tensor) -> Tensor:
    return multi_wise_op('O=I0+I1', a_t, b_t, op_name='add')
def sub(a_t : Tensor, b_t : Tensor) -> Tensor:
    return multi_wise_op('O=I0-I1', a_t, b_t, op_name='sub')
def mul(a_t : Tensor, b_t : Tensor) -> Tensor:
    return multi_wise_op('O=I0*I1', a_t, b_t, op_name='mul')
def div(a_t : Tensor, b_t : Tensor) -> Tensor:
    return multi_wise_op('O=I0/I1', a_t, b_t, op_name='div')
def min(a_t : Tensor, b_t : Tensor) -> Tensor:
    return multi_wise_op('O=fmin(I0,I1)', a_t, b_t, op_name='min')
def max(a_t : Tensor, b_t : Tensor) -> Tensor:
    return multi_wise_op('O=fmax(I0,I1)', a_t, b_t, op_name='max')
def square(a_t : Tensor) -> Tensor:
    return multi_wise_op('O=I0*I0', a_t, op_name='square')
def sqrt(a_t : Tensor) -> Tensor:
    return multi_wise_op('O=sqrt(I0)', a_t, op_name='sqrt')

def multi_wise_op_test():
    for _ in range(1):
      for op in ['+', '-', '*', '/', min, max, square]:
        for dtype in [np.float32]:
            shape_gen = range(1, 5)
            for shape_len in shape_gen:
                try:
                    a_shape = tuple(np.random.randint( 8, size=(shape_len,) )+1)

                    if np.random.randint(2) == 0:
                        b_shape = tuple(a_shape[np.random.randint(len(a_shape)):])
                        b_shape = (1,) if len(b_shape) == 0 else b_shape
                    else:
                        b_shape = list(a_shape)
                        b_shape[ np.random.randint(len(b_shape)) ] = 1
                        b_shape = tuple(b_shape)

                    shapes = [a_shape, b_shape]
                    if np.random.randint(2) == 0:
                        shapes = shapes[::-1]
                    a_shape, b_shape = shapes

                    a_n = np.random.randint( 1, 2**8, size=a_shape ).astype(dtype)
                    b_n = np.random.randint( 1, 2**8, size=b_shape ).astype(dtype)
                    a_t = Tensor.from_value(a_n)
                    b_t = Tensor.from_value(b_n)

                    if op == '+':
                        r_t = a_t + b_t
                    elif op == '-':
                        r_t = a_t - b_t
                    elif op == '*':
                        r_t = a_t * b_t
                    elif op == '/':
                        r_t = a_t / b_t
                    elif op == min:
                        r_t = min(a_t, b_t)
                    elif op == max:
                        r_t = max(a_t, b_t)
                    elif op == square:
                        r_t = square(a_t)

                    if op in ['+','-','*','/']:
                        r_n = eval(f'a_n {op} b_n')
                        r_n = r_n.astype(dtype)
                    elif op == min:
                        r_n = np.minimum(a_n, b_n)
                    elif op == max:
                        r_n = np.maximum(a_n, b_n)
                    elif op == square:
                        r_n = np.square(a_n)

                    if r_n.shape != r_t.shape:
                        raise Exception(f'shapes are not equal')

                    if np.abs(np.sum((np.ndarray.flatten(r_t.np() - r_n)))) > 1:
                        raise Exception(f'data is not equal')

                except:
                    raise Exception(f"""
    a_shape   : {a_shape}
    b_shape   : {b_shape}
    op        : {op}
    exception : {traceback.format_exc() }
    """)


