import traceback
from typing import List, Union, Tuple
import numpy as np
from ..Tensor import Tensor
from ..Kernel import Kernel
from ..TensorShape import TensorShape
from ..info.InfoBroadcast import InfoBroadcast
from ..KernelHelper import KernelHelper as KH


def multi_wise_op(op_text : str, *args, output_t:Tensor=None, output_dtype=None, op_name:str=None, ) -> Tensor:
    """
    operator for MultiWiseOpKernel ops with N inputs

    arguments
        op_text

        *args       List[ Tensor | number ]

        output_t            compute result to this Tensor.
                            Tensor may be with different shape, but should match total size.
                            gradfn will not be set.

        output_dtype

        op_name
    """

    if len(args) == 0:
        raise ValueError('args must be specified')

    tensor_args = [arg for arg in args if isinstance(arg, Tensor) ]
    if len(tensor_args) == 0:
        raise ValueError('At least one arg must be a Tensor')

    if output_dtype is None:
        if output_t is not None:
            output_dtype = output_t.dtype
        else:
            output_dtype = np.max( [ tensor_arg.dtype for tensor_arg in tensor_args ] )

    args_shapes_dtypes = []
    krn_args = []
    for arg in args:
        if isinstance(arg, Tensor):
            args_shapes_dtypes.append( (arg.shape, arg.dtype) )
            krn_args.append(arg._get_buffer())
        else:
            if isinstance(arg, (list,tuple)):
                raise ValueError('You cannot pass a list as argument. Use Tensor or single value.')
                
            args_shapes_dtypes.append( (None, output_dtype) )
            krn_args.append(output_dtype.type(arg))

    device = tensor_args[0].get_device()
    op = device.get_cached_class(_MultiWiseOp, tuple(args_shapes_dtypes), output_dtype, op_text)

    if output_t is None:
        output_t = Tensor ( op.info.output_shape, dtype=output_dtype, device=device )
        if op_name is not None:
            output_t._set_op_name (op_name)
    elif output_t.shape.size != op.info.output_shape.size:
        raise ValueError(f'output_t must have size { op.info.output_shape.size }')

    op.forward_krn.run(device, output_t._get_buffer(), *krn_args)

    return output_t

class _MultiWiseOp:
    def __init__(self, args_shapes_dtypes : List[Tuple[ Union[TensorShape,None], np.dtype]] ,
                       output_dtype : np.dtype,
                       op_text : str):

        self.info = info = InfoBroadcast( [ shape if shape is not None else TensorShape( (1,) ) for shape, _ in args_shapes_dtypes  ])

        defs, arg_defs, impls = [], [], []
        for i, (shape, dtype) in enumerate(args_shapes_dtypes):
            cl_dtype = KH.np_dtype_to_cl(dtype)
            axis_letter = chr(ord('A')+i)
            if shape is not None:
                defs.append( KH.define_axes_accessor(f"{axis_letter}", info.br_shapes[i]) )
                arg_defs.append( f", __global const {cl_dtype}* {axis_letter}_t" )
                impls.append( f"{cl_dtype} {axis_letter} = {axis_letter}_t[{axis_letter}_idx_mod({KH.axes_seq_enum('o', info.output_shape.rank)})];")
            else:
                arg_defs.append( f", {cl_dtype} {axis_letter}" )

        defs, arg_defs, impls = '\n'.join(defs), '\n'.join(arg_defs), '\n'.join(impls)

        output_cl_type = KH.np_dtype_to_cl(output_dtype)
        self.forward_krn = Kernel(global_shape=(info.output_shape.size,), kernel_text=f"""
{defs}
{KH.define_axes_accessor('O', info.output_shape)}
__kernel void impl(__global {output_cl_type}* O_t{arg_defs})
{{
size_t gid = get_global_id(0);
{KH.axes_idxs_from_var('o', info.output_shape.rank, 'gid')}
{impls}

{output_cl_type} O = O_t[gid];
{op_text};
O_t[gid] = O;
}}
""")


# def dual_wise_op_test():
#     for op in [add, binary_crossentropy, categorical_crossentropy, sub, max, min, mul, div]:
#         print(f'{op.__name__}()')
#         for _ in range(10):
#             if op == categorical_crossentropy:
#                 shape_gen = [2]
#             else:
#                 shape_gen = range(1, 5)

#             for shape_len in shape_gen:
#                 try:
#                     a_shape = tuple(np.random.randint( 8, size=(shape_len,) )+1)

#                     if op == categorical_crossentropy:
#                         b_shape = a_shape
#                     else:
#                         if np.random.randint(2) == 0:
#                             b_shape = tuple(a_shape[np.random.randint(len(a_shape)):])
#                             b_shape = (1,) if len(b_shape) == 0 else b_shape
#                         else:
#                             b_shape = list(a_shape)
#                             b_shape[ np.random.randint(len(b_shape)) ] = 1
#                             b_shape = tuple(b_shape)

#                         shapes = [a_shape, b_shape]
#                         if np.random.randint(2) == 0:
#                             shapes = shapes[::-1]
#                         a_shape, b_shape = shapes

#                     a_n = np.random.randint( 1, 2**8, size=a_shape ).astype(np.float32)
#                     b_n = np.random.randint( 1, 2**8, size=b_shape ).astype(np.float32)
#                     a_t = nn.Tensor_from_value(a_n)
#                     b_t = nn.Tensor_from_value(b_n)
#                     r_t = op(a_t, b_t)

#                     r_n_grad = np.random.randint( 2**8, size=r_t.shape ).astype(np.float32)

#                     a_t.get_grad().fill(1.0)
#                     b_t.get_grad().fill(1.0)
#                     nn.backward({r_t:r_n_grad}, grad_for_non_trainables=True)

#                     if op == div:
#                         # Test validness and gradient only for div
#                         r_n = a_n / b_n

#                         if r_n.shape != r_t.shape:
#                             raise Exception(f'shapes are not equal')
#                         if np.abs(np.sum((np.ndarray.flatten(r_t.np() - r_n)))) > 1:
#                             raise Exception(f'data is not equal')

#                         info = nc.info.InfoBroadcast( nc.TensorShape(a_shape), nc.TensorShape(b_shape) )

#                         a_n_grad = r_n_grad / b_n

#                         axes = info.a_shape_reduction_axes
#                         if axes.rank == 0:
#                             a_n_grad = a_n_grad.reshape(a_n.shape)
#                         else:
#                             a_n_grad = a_n_grad.sum( tuple(axes), keepdims=True )

#                         b_n_grad = r_n_grad * (-a_n/(b_n**2))

#                         axes = info.b_shape_reduction_axes
#                         if axes.rank == 0:
#                             b_n_grad = b_n_grad.reshape(b_n.shape)
#                         else:
#                             b_n_grad = b_n_grad.sum( tuple(axes), keepdims=True )

#                         if np.abs(np.sum((np.ndarray.flatten( a_t.get_grad().np() - 1.0 - a_n_grad)))) > 1:
#                             raise Exception(f'grad A is not equal')
#                         if np.abs(np.sum((np.ndarray.flatten( b_t.get_grad().np() - 1.0 - b_n_grad)))) > 1:
#                             raise Exception(f'grad B is not equal')
#                     else:
#                         if not a_t.has_grad():
#                             raise Exception(f'a_t has no grad')
#                         if not b_t.has_grad():
#                             raise Exception(f'b_t has no grad')

#                 except:
#                     raise Exception(f"""
# op        : {op}
# a_shape   : {a_shape}
# b_shape   : {b_shape}
# r_n_shape : {r_n.shape}
# exception : {traceback.format_exc() }
# """)

