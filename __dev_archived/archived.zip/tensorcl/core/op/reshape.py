from ..Tensor import Tensor
from ..info.InfoReshape import InfoReshape

def reshape(input_t : Tensor, new_shape):
    """
    reshape operator

    arguments

        new_shape    Iterable of ints
        
    Produces reference Tensor with new shape.                        
    """    
    
    info = input_t.get_device().get_cached_class(InfoReshape, input_t.shape, tuple(int(x) for x in new_shape) )
    
    return input_t._as_ref( info.output_shape )

# def flatten(input_t):
#     """
#     same as 
     
#      nn.reshape(x, (x.shape[0],-1) )
#     """
#     return reshape(input_t, (input_t.shape[0],-1) )
    