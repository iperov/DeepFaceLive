from typing import List, Union

from . import OpenCL as CL
from .DeviceInfo import DeviceInfo


class Device:
    """
    Represents physical TensorCL device
    """

    def __init__(self, device_info : DeviceInfo, **kwargs):
        if kwargs.get('_check', None) is None:
            raise Exception('You should not to create Device from constructor. Use get_device()')

        self._cached_data = {}      # cached data (per device) by key
        self._pooled_buffers = {}   # Pool of cached device buffers.
        self._compiled_kernels = {} # compiled kernels by key
        self._ctx_q = None          # CL command queue
        self._ctx = None            # CL context

        self._total_memory_allocated = 0
        self._total_buffers_allocated = 0
        self._total_memory_pooled = 0
        self._total_buffers_pooled = 0
        
        self._device_info = device_info
        self._device_id = _get_opencl_device_ids()[device_info.get_index()]
        
    def __del__(self):
        self.cleanup()

    def __eq__(self, other):
        if self is not None and other is not None and isinstance(self, Device) and isinstance(other, Device):
            return self._device_id.value == other._device_id.value
        return False

    def __hash__(self):
        return self._device_id.value

    def _get_ctx(self) -> CL.cl_context:
        # Create OpenCL context on demand
        if self._ctx is None:
            clr = CL.CLRESULT()
            ctx = CL.clCreateContext( None, 1, (CL.cl_device_id * 1)( self._device_id ), None, None, clr)
            if clr != CL.CLERROR.SUCCESS:
                raise Exception('Unable to create OpenCL context.')
            self._ctx = ctx
        return self._ctx

    def _get_ctx_q(self) -> CL.cl_command_queue:
        # Create CommandQueue on demand
        if self._ctx_q is None:
            clr = CL.CLRESULT()
            ctx_q = CL.clCreateCommandQueue(self._get_ctx(), self._device_id, CL.cl_command_queue_properties(0), clr)
            if clr != CL.CLERROR.SUCCESS:
                raise Exception('Unable to create OpenCL CommandQueue.')
            self._ctx_q = ctx_q
        return self._ctx_q


    def __str__(self):
        return f"{self._device_info.get_name()} [{(self._device_info.get_total_memory() / 1024**3) :.3}Gb]"

    def __repr__(self):
        return f'{self.__class__.__name__} object: ' + self.__str__()

    def set_cached_data(self, key, value):
        """
        
        All cached data will be freed with cleanup()
        """
        self._cached_data[key] = value
        
    def get_cached_data(self, key):
        return self._cached_data.get(key, None)

    def get_total_allocated_memory(self):
        return self._total_memory_allocated

    def get_max_malloc_size(self) -> int:
        size = CL.cl_ulong()
        clr = CL.clGetDeviceInfo(self._device_id, CL.CL_DEVICE_MAX_MEM_ALLOC_SIZE, CL.sizeof(size), CL.byref(size), None)
        if clr != CL.CLERROR.SUCCESS:
            raise Exception(f'clGetDeviceInfo error: {clr}')
        return size.value

    def _compile_kernel(self, key, kernel_text) -> CL.cl_kernel:
        """
        compile or get cached kernel
        """

        compiled_krn, prog = self._compiled_kernels.get(key, (None, None) )

        if compiled_krn is None:
            clr = CL.CLRESULT()
            prog = CL.clCreateProgramWithSource(self._get_ctx(), 1, CL.c_char_p(kernel_text.encode()), None, clr )
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clCreateProgramWithSource error {clr}, with kernel_text:\n{kernel_text}')

            clr = CL.clBuildProgram(prog, 1, (CL.cl_device_id*1)(self._device_id), CL.c_char_p('-cl-std=CL1.2 -cl-single-precision-constant'.encode()), None, None  )
            if clr != CL.CLERROR.SUCCESS:
                build_log_size = CL.c_size_t()
                clr = CL.clGetProgramBuildInfo(prog, self._device_id, CL.CL_PROGRAM_BUILD_LOG, 0, None, CL.byref(build_log_size) )
                if clr != CL.CLERROR.SUCCESS:
                    raise Exception(f'clGetProgramBuildInfo,error: {clr}')

                build_log = CL.create_string_buffer(build_log_size.value)
                clr = CL.clGetProgramBuildInfo(prog, self._device_id, CL.CL_PROGRAM_BUILD_LOG, build_log_size.value, build_log, None )
                if clr != CL.CLERROR.SUCCESS:
                    raise Exception(f'clGetProgramBuildInfo error: {clr}')

                build_log = str(build_log.value, 'utf-8')
                raise Exception(f'clBuildProgram error:\n\n{build_log}')

            num_kernels = CL.cl_uint()
            clr = CL.clCreateKernelsInProgram(prog, 0, None, CL.byref(num_kernels))
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clCreateKernelsInProgram error: {clr}')

            if num_kernels.value != 1:
                raise Exception(f'Kernel must contain only one __kernel:\n\n{kernel_text}')

            kernels = (CL.cl_kernel * num_kernels.value)()
            clr = CL.clCreateKernelsInProgram(prog, num_kernels.value, kernels, None)
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clCreateKernelsInProgram error: {clr}')

            compiled_krn = kernels[0]
            self._compiled_kernels[key] = (compiled_krn, prog)

        return compiled_krn

    def _cl_mem_alloc(self, size) -> CL.cl_mem:
        clr = CL.CLRESULT()
        mem = CL.clCreateBuffer(self._get_ctx(), CL.CL_MEM_READ_WRITE, size, None, clr)
        if clr == CL.CLERROR.SUCCESS:
            # Fill one byte to check memory availability
            ev = CL.cl_event()
            clr = CL.clEnqueueFillBuffer (self._get_ctx_q(), mem, (CL.c_char * 1)(), 1, 0, 1, 0, None, ev )
            if clr == CL.CLERROR.SUCCESS:
                CL.clReleaseEvent(ev)
                self._total_memory_allocated += size
                self._total_buffers_allocated += 1
                return mem
        return None

    def _cl_mem_free(self, mem : CL.cl_mem):
        size = CL.c_size_t()
        clr = CL.clGetMemObjectInfo(mem, CL.CL_MEM_SIZE, CL.sizeof(size), CL.byref(size), None )
        if clr != CL.CLERROR.SUCCESS:
            raise Exception(f'clGetMemObjectInfo error: {clr}')
        size = size.value
        self._total_memory_allocated -= size
        self._total_buffers_allocated -= 1
        clr = CL.clReleaseMemObject(mem)
        if clr != CL.CLERROR.SUCCESS:
            raise Exception(f'clReleaseMemObject error: {clr}')

    def _cl_mem_pool_alloc(self, size):
        """
        allocate or get cl_mem from pool
        """
        pool = self._pooled_buffers

        # First try to get pooled buffer
        ar = pool.get(size, None)
        if ar is not None and len(ar) != 0:
            mem = ar.pop(-1)
            self._total_memory_pooled -= size
            self._total_buffers_pooled -= 1
        else:
            # No pooled buffer, try to allocate new
            while True:
                mem = self._cl_mem_alloc(size)
                if mem is None:
                    # MemoryError. Finding largest pooled buffer to release
                    buf_to_release = None
                    for size_key in sorted(list(pool.keys()), reverse=True):
                        ar = pool[size_key]
                        if len(ar) != 0:
                            buf_to_release = ar.pop(-1)
                            break

                    if buf_to_release is not None:
                        # Release pooled buffer and try to allocate again
                        self._cl_mem_free(buf_to_release)
                        continue

                    raise Exception(f'Unable to allocate {size // 1024**2}Mb on {str(self)}')
                

                break

        return mem

    def _cl_mem_pool_free(self, mem : CL.cl_mem):
        """
        Put cl_mem to pool for reuse in future.
        """
        size = CL.c_size_t()
        clr = CL.clGetMemObjectInfo(mem, CL.CL_MEM_SIZE, CL.sizeof(size), CL.byref(size), None )
        if clr != CL.CLERROR.SUCCESS:
            raise Exception(f'clGetMemObjectInfo error: {clr}')
        size = size.value

        pool = self._pooled_buffers
        ar = pool.get(size, None)
        if ar is None:
            ar = pool[size] = []
        ar.append(mem)

        self._total_memory_pooled += size
        self._total_buffers_pooled += 1


    def print_stat(self):
        s = f'''
Total memory allocated:  {self._total_memory_allocated}
Total buffers allocated: {self._total_buffers_allocated}
Total memory pooled:     {self._total_memory_pooled}
Total buffers pooled:    {self._total_buffers_pooled}
N of compiled kernels:   {len(self._compiled_kernels)}
N of cacheddata:         {len(self._cached_data)}
'''
        print(s)

    def wait(self):
        """
        Wait to finish all queued operations on this Device
        """
        clr = CL.clFinish(self._get_ctx_q())
        if clr != CL.CLERROR.SUCCESS:
            raise Exception(f'clFinish error: {clr}')

    def cleanup(self):
        """
        Frees all resources from this Device.
        """
        self._cached_data = {}

        pool = self._pooled_buffers
        for size_key in pool.keys():
            for mem in pool[size_key]:
                self._cl_mem_free(mem)
        self._pooled_buffers = {}
        self._total_memory_pooled = 0
        self._total_buffers_pooled = 0

        if self._total_memory_allocated != 0:
            raise Exception('Unable to cleanup CLDevice, while not all Buffers are deallocated.')

        for kernel, prog in self._compiled_kernels.values():
            clr = CL.clReleaseKernel(kernel)
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clReleaseKernel error: {clr}')

            clr = CL.clReleaseProgram(prog)
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clReleaseProgram error: {clr}')
        self._compiled_kernels = {}

        if self._ctx_q is not None:
            clr = CL.clReleaseCommandQueue(self._ctx_q)
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clReleaseCommandQueue error: {clr}')
            self._ctx_q = None

        if self._ctx is not None:
            clr = CL.clReleaseContext(self._ctx)
            if clr != CL.CLERROR.SUCCESS:
                raise Exception(f'clReleaseContext error: {clr}')
            self._ctx = None


_opencl_device_ids = None
def _get_opencl_device_ids() -> List[CL.cl_device_id]:
    global _opencl_device_ids
    if _opencl_device_ids is None:
        _opencl_device_ids = []
        device_types = CL.CL_DEVICE_TYPE_CPU | CL.CL_DEVICE_TYPE_ACCELERATOR | CL.CL_DEVICE_TYPE_GPU

        while True:
            num_platforms = CL.cl_uint()
            if CL.clGetPlatformIDs(0, None, num_platforms) != CL.CLERROR.SUCCESS or \
                num_platforms.value == 0:
                break

            platforms = (CL.cl_platform_id * num_platforms.value) ()
            if CL.clGetPlatformIDs(num_platforms.value, platforms, None) != CL.CLERROR.SUCCESS:
                break

            for i_platform in range(num_platforms.value):
                platform = platforms[i_platform]
                num_devices = CL.cl_uint(0)
                if CL.clGetDeviceIDs(platform, device_types, 0, None, num_devices) != CL.CLERROR.SUCCESS or \
                    num_devices.value == 0:
                    continue

                device_ids = (CL.cl_device_id * num_devices.value)()
                if CL.clGetDeviceIDs(platform, device_types, num_devices.value, device_ids, None) != CL.CLERROR.SUCCESS:
                    continue

                for i in range(num_devices.value):
                    _opencl_device_ids.append(device_ids[i])

            break
    return _opencl_device_ids


def get_available_devices_info() -> List[DeviceInfo]:
    """
    returns a list of available picklable DeviceInfo's 
    """
    devices = []
    for device_index, device_id in enumerate(_get_opencl_device_ids()):
        device_name = 'undefined'
        device_total_memory = 0

        name_size = CL.c_size_t()
        if CL.clGetDeviceInfo(device_id, CL.CL_DEVICE_NAME, 0, None, name_size) == CL.CLERROR.SUCCESS:
            name_value = CL.create_string_buffer(name_size.value)
            if CL.clGetDeviceInfo(device_id, CL.CL_DEVICE_NAME, name_size.value, name_value, None) == CL.CLERROR.SUCCESS:
                device_name = str(name_value.value, 'ascii')

        global_mem_size = CL.cl_ulong()
        if CL.clGetDeviceInfo(device_id, CL.CL_DEVICE_GLOBAL_MEM_SIZE, CL.sizeof(global_mem_size), CL.byref(global_mem_size), None) == CL.CLERROR.SUCCESS:
            device_total_memory = global_mem_size.value

        devices.append( DeviceInfo(index=device_index, name=device_name, total_memory=device_total_memory ) )

    return devices

_default_device = None

def get_default_device() -> Device:
    global _default_device
    if _default_device is None:
        _default_device = get_device(0)
    return _default_device
    
def set_default_device(device):
    global _default_device
    _default_device = device
    
_devices = {}
def get_device(arg : Union[None, int, Device, DeviceInfo]) -> Device:
    """
    get physical TensorCL device.

        arg     int         - by index
                DeviceInfo  - by device info
                Device      - returns the same
    """
    global _devices
        
    if isinstance(arg, int):
        devices_info = get_available_devices_info()
        if arg < len(devices_info):
            arg = devices_info[arg]
        else:
            raise ValueError(f'index out of avaiable range of device [0...{len(devices_info)-1}]')
    elif isinstance(arg, Device):
        return arg
    elif not isinstance(arg, DeviceInfo):
        raise ValueError(f'Unknown type of arg {arg.__class__}')

    device = _devices.get(arg, None)
    if device is None:
        device = _devices[arg] = Device(arg, _check=1)

    return device


def cleanup_devices():
    global _devices

    for device in list(_devices.values()):
        device.cleanup()
    _devices = {}