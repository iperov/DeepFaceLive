from typing import List
from ..TensorShape import TensorShape
from ..TensorAxes import TensorAxes
import numpy as np

class InfoBroadcast:
    """
    Broadcast info for multi shapes.

    arguments

        shapes     List[TensorShape]

    errors during the construction:

        ValueError

    Example:
     shapes   = (   3,),
                (3, 1,)
                           #Example | comment
                            
     output_shape          #(3, 3)    broadcasted together output_shape
     
     br_shapes             #(1, 3)    shape[0] broadcasted to output_shape rank
                           #(3, 1)    shape[1] broadcasted to output_shape rank

     shapes_tiles          #(3, 1)    tiles to make output_shape from br_shapes[0]
                           #(1, 3)    tiles to make output_shape from br_shapes[1]

     shapes_reduction_axes #(0,)      reduction_axes to make shapes[0] from output_shape
                           #(1,)      reduction_axes to make shapes[1] from output_shape
    """

    __slots__ = ['output_shape', 'br_shapes', 'shapes_tiles', 'shapes_reduction_axes']

    def __init__(self, shapes : List[TensorShape]):
        
        highest_rank = sorted([shape.rank for shape in shapes])[-1]
        
        # Broadcasted all shapes to highest rank with (1,)-s in from left side
        br_shapes = [ (1,)*(highest_rank-shape.rank) + shape for shape in shapes ]
        
        # Determine output_shape from all shapes
        output_shape = TensorShape( np.max( [ [ br_shape.shape[axis] for br_shape in br_shapes] for axis in range(highest_rank) ], axis=1  ) )
                     
        shapes_tiles = []
        shapes_reduction_axes = []
        for br_shape in br_shapes:
            shape_tile = []
            shape_reduction_axes = []
            for axis, (x,y) in enumerate(zip(br_shape.shape, output_shape.shape)):
                if x != y:
                    if x == 1 and y != 1:
                        shape_tile.append(y)
                        shape_reduction_axes.append(axis)
                    elif x != 1 and y == 1:
                        shape_tile.append(1)
                    else:
                        raise ValueError(f'operands could not be broadcast together with shapes {br_shape} {output_shape}')
                else:
                    shape_tile.append(1)
                    
            shapes_tiles.append(shape_tile)
            shapes_reduction_axes.append( TensorAxes(shape_reduction_axes) )
            
        
        self.output_shape : TensorShape = TensorShape(output_shape)
        self.br_shapes : List[TensorShape] = br_shapes
        self.shapes_tiles : List[List] = shapes_tiles
        self.shapes_reduction_axes : List [TensorAxes] = shapes_reduction_axes
        
