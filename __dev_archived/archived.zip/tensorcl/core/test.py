from .op.multi_wise_op import multi_wise_op_test
from .op.transpose import transpose_test
from .op.matmul import matmul_test
from .Device import get_device, set_default_device, get_default_device
from .core import cleanup

def test_all():
    cleanup()
    
    prev_device = get_default_device()
    
    device = get_device(0)
    set_default_device(device)
    
    test_funcs = [ matmul_test,
                   transpose_test,
                   multi_wise_op_test,
                ]
                
    for test_func in test_funcs:
        print(f'{test_func.__name__}()')
        test_func()
        device.cleanup()
    device.print_stat()
    
    cleanup()   
    
    set_default_device(prev_device)
    
    print('Done.')
