from .core.Device import get_available_devices_info, get_device
from .core.DeviceInfo import DeviceInfo, DevicesInfo
from .core.op.multi_wise_op import multi_wise_op
from .core.op.reshape import reshape

from .core.Tensor import Tensor
from .core.TensorImpl import *
