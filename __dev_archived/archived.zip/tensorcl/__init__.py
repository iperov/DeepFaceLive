"""
Float32CL

Lightweight ndarray library using OpenCL 1.2

For code simplicity the library works only with float32 values, but internal and custom kernels may work with any CL-type.
"""

from .core.Device import get_available_devices_info, get_device, get_default_device, set_default_device
from .core.DeviceInfo import DeviceInfo
from .core.Kernel import Kernel

from .core.op.multi_wise_op import add, sub, mul, div, min, max, square, sqrt, multi_wise_op
from .core.op.reshape import reshape
from .core.op.transpose import transpose, depth_to_space, space_to_depth

from .core.Tensor import Tensor
from .core import TensorImpl as _

from .core import initializer

from .core.test import test_all

from .core.core import cleanup