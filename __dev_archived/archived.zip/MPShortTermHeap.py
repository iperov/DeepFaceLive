
class MPShortTermHeap:
    """
    Multiprocess shared heap for short term allocations
    """
    
    