import numpy as np

from ..AShape import AShape
from ..backend import Kernel
from ..HKernel import HKernel
from ..info import BroadcastInfo, Conv2DInfo
from ..SCacheton import SCacheton
from ..Tensor import Tensor


def binary_erode_circle (input_t : Tensor, radius=1, iterations=1, dtype=None):
    """
    Binary erode operator.

     input_t     Tensor (...,H,W)

    ...-head part of shapes will be broadcasted to each other
    """

    op = SCacheton.get(_BinaryErodeOp, input_t.shape, input_t.dtype, radius, dtype)
    
    device = input_t.get_device()
    
    if iterations <= 0:
        return input_t.copy()
    else:
        for i in range(iterations):
            if i == 0:
                buf_in = input_t
            else:
                buf_in, buf_out = buf_out, buf_in
            if i <= 1:            
                buf_out = Tensor( op.o_shape, op.o_dtype, device=device )
            device.run_kernel(op.forward_krn, buf_out.get_buffer(), buf_in.get_buffer() )

    return buf_out

class _BinaryErodeOp():
    def __init__(self, i_shape : AShape, i_dtype, k_shape : AShape, k_dtype, o_dtype):
        self.o_dtype = o_dtype = o_dtype if o_dtype is not None else i_dtype

        if i_shape.ndim < 2:
            raise ValueError(f'i_shape.ndim must be >= 2')

        if k_shape.ndim < 2:
            raise ValueError(f'k_shape.ndim must be >= 2')

        IH,IW = i_shape[-2:]
        KH,KW = k_shape[-2:]

        ci = Conv2DInfo(IH, IW, KH, KW, stride=1, dilation=1, padding='same')

        if i_shape.ndim == 2 and k_shape.ndim == 2:
            # nothing to broadcast
            i_br_shape = i_shape
            k_br_shape = k_shape

            o_shape = AShape([ci.OH, ci.OW])
        else:
            op = BroadcastInfo([ i_shape[:-2], k_shape[:-2] ])

            i_br_shape = op.br_shapes[0] + i_shape[-2:]
            k_br_shape = op.br_shapes[1] + k_shape[-2:]

            o_shape = op.o_shape + [ci.OH, ci.OW]

        self.o_shape = o_shape

        self.forward_krn = Kernel(global_shape=(o_shape.size,), kernel_text=f"""
{HKernel.define_tensor('O', o_shape, o_dtype)}
{HKernel.define_tensor('I', i_br_shape, i_dtype)}
{HKernel.define_tensor('K', k_br_shape, k_dtype)}

#define PADL {ci.PADL}
#define PADT {ci.PADT}

__kernel void impl(__global O_PTR_TYPE* O_PTR_NAME, __global const I_PTR_TYPE* I_PTR_NAME, __global const K_PTR_TYPE* K_PTR_NAME)
{{
    size_t gid = get_global_id(0);
    {HKernel.decompose_idx_to_axes_idxs('gid', 'O', o_shape.ndim)}

    int kc = 0;
    int vc = 0;
    
    {'#pragma unroll' if KH <= 9 else ''}
    for (int km2=0; km2<Km2; ++km2)
    {'#pragma unroll' if KW <= 9 else ''}
    for (int km1=0; km1<Km1; ++km1)
    {{  
        // 
        
        if ( K_GLOBAL_LOAD(K_IDX_MOD({HKernel.axes_seq_enum('O', o_shape.ndim-2, suffix='km2,km1' )})) != (K_TYPE)0)
        {{
            ++kc;            
            
            int im2 = -PADT + km2 + om2;
            int im1 = -PADL + km1 + om1;
                
            I_TYPE i_val = (im1 >= 0 & im1 < Im1 & im2 >= 0 & im2 < Im2) ?
                           I_GLOBAL_LOAD(I_IDX_MOD({HKernel.axes_seq_enum('O', o_shape.ndim-2, suffix='im2,im1' )})) 
                           : 0;
            
            if (i_val != (I_TYPE)0)
                ++vc;
        }}
    }}

    O_GLOBAL_STORE(gid, (kc == vc ? I_GLOBAL_LOAD(gid) : (O_TYPE) 0 ) );
}}
""")


